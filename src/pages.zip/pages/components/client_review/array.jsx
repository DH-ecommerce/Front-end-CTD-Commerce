import perfil from "./Imgs/image_perfil.jpg"

const perfil_array = [{
    id: 1,
    image: perfil,
    name: "Gustavo",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus molestie eros, sed lobortis augue. Nam tempus enim maximus erat molestie accumsan.", 
    time: "1 month"
},

{
    id: 2,
    image: perfil,
    name: "Gustavo",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus molestie eros, sed lobortis augue. Nam tempus enim maximus erat molestie accumsan.", 
    time: "1 month"
},
{
    id: 3,
    image: perfil,
    name: "Gustavo",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus molestie eros, sed lobortis augue. Nam tempus enim maximus erat molestie accumsan.", 
    time: "1 month"
},
{
    id: 4,
    image: perfil,
    name: "Gustavo",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus molestie eros, sed lobortis augue. Nam tempus enim maximus erat molestie accumsan.", 
    time: "1 month"
}
]

export default perfil_array;